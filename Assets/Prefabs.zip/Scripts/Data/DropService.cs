using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class DropRangeDto { public ulong min; public ulong max; public float chance = 1f; }

[Serializable]
public class DropTableRootDto
{
    public Dictionary<string, Dictionary<string, DropRangeDto>> enemies;
}

public class DropService
{
    static DropService _instance;
    public static DropService Instance => _instance ??= new DropService();

    readonly Dictionary<string, Dictionary<Metal, DropRangeDto>> _tables = new();

    DropService() { Load(); }

    void Load()
    {
        var json = JsonUtils.ReadStreamingText("drop_tables.json");
        if (string.IsNullOrEmpty(json)) { Debug.LogWarning("DropService: drop_tables.json missing"); return; }

        var dto = JsonUtility.FromJson<DropTableRootDto>(json);
        if (dto?.enemies == null) return;

        foreach (var (enemyId, metalMap) in dto.enemies)
        {
            var typed = new Dictionary<Metal, DropRangeDto>();
            foreach (var (metalStr, range) in metalMap)
            {
                if (Enum.TryParse<Metal>(metalStr, true, out var metal))
                    typed[metal] = range;
                else
                    Debug.LogWarning($"DropService: Unknown metal '{metalStr}' in enemy '{enemyId}'");
            }
            _tables[enemyId] = typed;
        }
    }

    /// Rolls a payout for an enemyId. Returns empty if none configured.
    public Dictionary<Metal, ulong> Roll(string enemyId)
    {
        var result = new Dictionary<Metal, ulong>();
        if (!_tables.TryGetValue(enemyId, out var metals)) return result;

        foreach (var (metal, r) in metals)
        {
            if (UnityEngine.Random.value > Mathf.Clamp01(r.chance)) continue;
            ulong lo = r.min, hi = Math.Max(r.min, r.max);
            ulong amt = lo == hi ? lo : (ulong)UnityEngine.Random.Range((int)lo, (int)hi + 1);
            if (amt > 0) result[metal] = amt;
        }
        return result;
    }
}
