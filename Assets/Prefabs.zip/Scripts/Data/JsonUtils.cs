using System.IO;
using UnityEngine;

public static class JsonUtils
{
    public static string ReadStreamingText(string relativePath)
    {
        // Editor/Standalone MVP path (no WebRequest complexity)
        string full = Path.Combine(Application.streamingAssetsPath, relativePath);
        return File.Exists(full) ? File.ReadAllText(full) : null;
    }
}
