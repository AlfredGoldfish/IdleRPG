using UnityEngine;

[RequireComponent(typeof(Health2D))]
public class DamagePopupOnHealth2D : MonoBehaviour
{
    [Header("Popup Prefab")]
    [SerializeField] DamagePopup3D popupPrefab;

    [Header("Positioning")]
    [Tooltip("Anchor at the top of the enemy (e.g., head). If set, popups spawn here.")]
    [SerializeField] Transform anchor;

    [Tooltip("Parent the popup under the anchor so it follows enemy movement.")]
    [SerializeField] bool parentToAnchor = true;

    [Tooltip("Vertical padding above the anchor/top.")]
    [SerializeField] float extraY = 0.15f;

    [Tooltip("Small random horizontal jitter.")]
    [SerializeField] float xJitter = 0.08f;

    [Tooltip("Push slightly toward the camera so it renders in front of sprites.")]
    [SerializeField] float zOffset = -0.1f;

    Health2D health;

    void Reset()
    {
        // Auto-find common anchor name to reduce manual wiring errors.
        if (!anchor)
        {
            var t = transform.Find("PopupAnchor");
            if (t) anchor = t;
        }
    }

    void Awake()
    {
        health = GetComponent<Health2D>();
        if (!health)
            Debug.LogError($"[{name}] DamagePopupOnHealth2D: missing Health2D (should be auto-required).");

        if (!popupPrefab)
            Debug.LogWarning($"[{name}] DamagePopupOnHealth2D: popupPrefab is NOT assigned.");
        if (!anchor)
            Debug.LogWarning($"[{name}] DamagePopupOnHealth2D: anchor is NOT assigned (will use bounds/world fallback).");
    }

    void OnEnable()
    {
        if (health != null) health.OnDamaged += HandleDamaged;
    }

    void OnDisable()
    {
        if (health != null) health.OnDamaged -= HandleDamaged;
    }

    void HandleDamaged(int amount)
    {
        if (amount <= 0) return;
        if (!popupPrefab) { Debug.LogWarning($"[{name}] No popupPrefab assigned; cannot spawn."); return; }

        var popup = SpawnPopup();
        if (!popup) return;

        if (popup.text == null)
            popup.text = popup.GetComponentInChildren<TMPro.TMP_Text>();

        if (popup.text != null)
            popup.text.text = amount.ToString();
        else
            Debug.LogWarning($"[{name}] Spawned popup but TMP_Text was not found/assigned.");
    }

    DamagePopup3D SpawnPopup()
    {
        if (anchor != null && parentToAnchor)
        {
            var popup = Instantiate(popupPrefab, anchor);
            popup.transform.localPosition = new Vector3(Random.Range(-xJitter, xJitter), extraY, zOffset);
            popup.transform.localRotation = Quaternion.identity;
            popup.transform.localScale = Vector3.one;
            return popup;
        }
        else
        {
            Vector3 pos = ComputeWorldSpawnPosition();
            return Instantiate(popupPrefab, pos, Quaternion.identity);
        }
    }

    Vector3 ComputeWorldSpawnPosition()
    {
        if (anchor != null)
        {
            var p = anchor.position;
            p.x += Random.Range(-xJitter, xJitter);
            p.y += extraY;
            p.z += zOffset;
            return p;
        }

        if (TryGetWorldBounds(out var b))
        {
            float x = b.center.x + Random.Range(-xJitter, xJitter);
            float y = b.max.y + extraY;
            float z = transform.position.z + zOffset;
            return new Vector3(x, y, z);
        }

        return transform.position + new Vector3(0f, extraY, zOffset);
    }

    bool TryGetWorldBounds(out Bounds result)
    {
        result = default;
        bool has = false;

        var cols = GetComponentsInChildren<Collider2D>();
        foreach (var c in cols)
        {
            if (!c.enabled) continue;
            if (!has) { result = c.bounds; has = true; }
            else result.Encapsulate(c.bounds);
        }
        if (has) return true;

        var rends = GetComponentsInChildren<Renderer>();
        foreach (var r in rends)
        {
            if (!r.enabled) continue;
            if (!has) { result = r.bounds; has = true; }
            else result.Encapsulate(r.bounds);
        }
        return has;
    }

    // --- Debug helpers ---
    [ContextMenu("Spawn Test Popup Here")]
    void DebugSpawnTest()
    {
        if (!popupPrefab) { Debug.LogWarning($"[{name}] No popupPrefab assigned; cannot test."); return; }
        var p = SpawnPopup();
        if (p && p.text) p.text.text = "TEST";
        Debug.Log($"[{name}] Spawned test popup {(anchor ? "as child of anchor" : "at world pos")}.");
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        var pos = anchor ? anchor.position + new Vector3(0, extraY, 0) : transform.position + new Vector3(0, extraY, 0);
        Gizmos.DrawWireSphere(pos, 0.05f);
    }
}
